# Wing

AI Dating Assistant – Your smart wingman for real connections.

Built with Flutter Web, designed in GitHub Codespaces.