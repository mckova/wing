import 'package:flutter/material.dart';

void main() {
  runApp(const WingApp());
}

class WingApp extends StatelessWidget {
  const WingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Wing',
      theme: ThemeData(
        primarySwatch: Colors.pink,
        useMaterial3: true,
      ),
      home: const GoalSelectionScreen(),
    );
  }
}

class GoalSelectionScreen extends StatefulWidget {
  const GoalSelectionScreen({super.key});

  @override
  State<GoalSelectionScreen> createState() => _GoalSelectionScreenState();
}

class _GoalSelectionScreenState extends State<GoalSelectionScreen> {
  String? selectedGoal;

  final List<String> goals = [
    'Serious relationship',
    'Short-term connection / hookups',
    'Exploring sexuality',
    'Emotional exploration',
    'Open to see what happens',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('What are you currently looking for?')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ...goals.map(
              (goal) => RadioListTile<String>(
                title: Text(goal),
                value: goal,
                groupValue: selectedGoal,
                onChanged: (value) {
                  setState(() {
                    selectedGoal = value;
                  });
                },
              ),
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: selectedGoal == null
                  ? null
                  : () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Selected: $selectedGoal')),
                      );
                    },
              child: const Text('Continue'),
            )
          ],
        ),
      ),
    );
  }
}
